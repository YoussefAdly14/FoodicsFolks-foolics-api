// GET/admin/dashboard - returns the admin dashboard, includes user details, stock and order_details

const { PrismaClient } = require('../generated/prisma')
const prisma = new PrismaClient()

// POST/admin-login - Admin login endpoint
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')

// POST admin-login
const loginAdmin = async (req, res) => {
    const { email, password } = req.body

    if (!email || !password) {
        return res
            .status(400)
            .json({ message: 'Email and Password are required' })
    }

    try {
        const user = await prisma.users.findUnique({
            where: { email },
        })

        if (!user || !user.is_admin) {
            // Check if user exists and is marked as admin
            throw {
                status: 401,
                message: 'Unauthorized: Admin access required',
            }
        }

        const validPassword = await bcrypt.compare(password, user.password_hash)

        if (!validPassword) {
            throw { status: 401, message: 'Invalid email or password' }
        }

        const token = jwt.sign(
            { id: user.id, is_admin: true },
            process.env.JWT_SECRET,
            {
                expiresIn: '1h',
            }
        )

        return res.status(200).json({
            result: {
                admin_details: {
                    id: user.id,
                    full_name: user.full_name,
                    email: user.email,
                },
                auth_token: token,
            },
        })
    } catch (error) {
        console.error('Admin login error:', error)

        if (error.status && error.message) {
            return res.status(error.status).json({ message: error.message })
        }

        return res.status(500).json({ message: 'Server error' })
    }
}

const getAdminDashboard = async (req, res) => {
    try {
        const ordersWithUsers = await prisma.orders.findMany({
            where: {
                user: {
                    is_admin: false,
                },
            },
            select: {
                id: true,
                total: true,
                status: true,
                created_at: true,
                user: {
                    select: {
                        id: true,
                        full_name: true,
                        phone: true,
                        email: true,
                    },
                },
                order_items: {
                    select: {
                        product: {
                            select: {
                                id: true,
                                name: true,
                            },
                        },
                        quantity: true,
                    },
                },
            },
        })

        if (ordersWithUsers.length === 0) {
            throw { status: 404, message: 'No orders with users found' }
        }

        const stock = await prisma.products.findMany({
            select: {
                id: true,
                name: true,
                stock: true,
            },
        })

        if (stock.length === 0) {
            throw { status: 404, message: 'No stock data found' }
        }

        res.status(200).json({
            message: 'Admin dashboard data retrieved successfully',
            orders: ordersWithUsers,
            stock,
        })
    } catch (error) {
        console.error('Error fetching admin dashboard data:', error)

        if (error.status) {
            return res.status(error.status).json({ message: error.message })
        }
        res.status(500).json({
            message: 'Failed to fetch admin dashboard data',
        })
    }
}

// PATCH/admin/stock - updates the stock of a product
const patchStock = async (req, res) => {
    const { product_id, stock } = req.body

    if (!product_id || stock === undefined) {
        return res
            .status(400)
            .json({ message: 'Product ID and stock are required' })
    }

    if (!Number.isInteger(stock) || stock < 0) {
        return res
            .status(400)
            .json({ message: 'Stock must be a positive integer' })
    }

    try {
        const product = await prisma.products.findUnique({
            where: { id: product_id },
        })

        if (!product) {
            throw { status: 404, message: 'Product not found' }
        }

        const updatedProduct = await prisma.products.update({
            where: { id: product_id },
            data: { stock },
        })

        res.status(200).json({
            message: 'Product stock updated successfully',
            product: updatedProduct,
        })
    } catch (error) {
        console.error('Error updating product stock:', error)

        if (error.status) {
            return res.status(error.status).json({ message: error.message })
        }
        res.status(500).json({
            message: 'Failed to update product stock',
        })
    }
}

// PATCH/admin/:id/order-status - updates the status of an order

const updateOrderStatus = async (req, res) => {
    const { id } = req.params
    const { status } = req.body

    const allowedStatuses = ['pending', 'processing', 'shipped', 'delivered']
    if (!id || !status) {
        return res
            .status(400)
            .json({ message: 'Order ID and status are required' })
    }

    if (!Number.isInteger(Number(id))) {
        return res.status(400).json({ message: 'Order ID must be an integer' })
    }

    if (!allowedStatuses.includes(status)) {
        return res.status(400).json({ message: 'Invalid order status' })
    }

    try {
        const order = await prisma.orders.findUnique({
            where: { id: Number(id) },
        })

        if (!order) {
            return res.status(404).json({ message: 'Order not found' })
        }

        const updatedOrder = await prisma.orders.update({
            where: { id: Number(id) },
            data: { status },
        })

        return res.status(200).json({
            message: 'Order status updated successfully',
            order: updatedOrder,
        })
    } catch (error) {
        console.error('Error updating order status:', error)

        return res.status(500).json({
            message: 'Failed to update order status',
        })
    }
}

module.exports = {
    getAdminDashboard,
    loginAdmin,
    patchStock,
    updateOrderStatus,
}

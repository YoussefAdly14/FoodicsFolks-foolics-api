const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const { PrismaClient } = require('../generated/prisma')
const prisma = new PrismaClient()

// POST/auth/register - Registers a new user
const registerUser = async (req, res) => {
    const { full_name, email, password, phone } = req.body

    if (!full_name || !email || !password || !phone) {
        return res.status(400).json({ message: 'All fields are required' })
    }

    try {
        const userExists = await prisma.users.findFirst({
            where: {
                OR: [{ email }, { phone }],
            },
        })

        if (userExists) {
            throw { status: 400, message: 'User already exists' }
        }

        const hashedPassword = await bcrypt.hash(password, 10)

        const newUser = await prisma.users.create({
            data: {
                full_name,
                phone,
                password_hash: hashedPassword,
                email,
            },
            select: {
                id: true,
                full_name: true,
                email: true,
            },
        })

        const token = jwt.sign({ id: newUser.id }, process.env.JWT_SECRET, {
            expiresIn: '1h',
        })

        return res.status(201).json({
            message: 'User registered successfully',
            user: newUser,
            token,
        })
    } catch (error) {
        console.error('Error registering user:', error)

        if (error.status && error.message) {
            return res.status(error.status).json({ message: error.message })
        }

        return res.status(500).json({ message: 'Server error' })
    }
}

// POST/auth/login - Logs in a user
const loginUser = async (req, res) => {
    const { email, password } = req.body

    if (!email || !password) {
        return res
            .status(400)
            .json({ message: 'Email and Password are required' })
    }

    try {
        const user = await prisma.users.findUnique({
            where: { email },
        })

        if (!user) {
            throw { status: 401, message: 'Invalid email or password' }
        }

        if (user.is_admin) {
            throw {
                status: 403,
                message: 'Admins are not allowed to log in here',
            }
        }

        const validPassword = await bcrypt.compare(password, user.password_hash)

        if (!validPassword) {
            throw { status: 401, message: 'Invalid email or password' }
        }

        const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, {
            expiresIn: '1h',
        })

        return res.status(200).json({
            result: {
                user_details: {
                    id: user.id,
                    full_name: user.full_name,
                    email: user.email,
                },
                auth_token: token,
            },
        })
    } catch (error) {
        console.error('Login error:', error)

        if (error.status && error.message) {
            return res.status(error.status).json({ message: error.message })
        }

        return res.status(500).json({ message: 'Server error' })
    }
}

module.exports = {
    registerUser,
    loginUser,
}

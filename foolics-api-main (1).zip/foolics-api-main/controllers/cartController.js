const { PrismaClient } = require('../generated/prisma')
const prisma = new PrismaClient()

// POST /cart - Add or update cart item
const addProduct = async (req, res) => {
    const { product_id, quantity } = req.body
    const userId = req.user.id

    if (quantity === undefined || quantity === null || !product_id) {
        return res
            .status(400)
            .json({ message: 'Quantity and product_id are required' })
    }

    if (quantity <= 0) {
        return res
            .status(400)
            .json({ message: 'Quantity must be a positive value' })
    }

    try {
        const product = await prisma.products.findUnique({
            where: { id: product_id },
            select: { stock: true },
        })

        if (!product) {
            throw { status: 404, message: 'Product not found' }
        }

        if (quantity > product.stock) {
            throw { status: 400, message: 'Not enough stock available' }
        }

        let cart = await prisma.carts.findUnique({
            where: { user_id: userId },
            select: { id: true },
        })

        if (!cart) {
            cart = await prisma.carts.create({
                data: { user_id: userId },
                select: { id: true },
            })
        }

        const existingItem = await prisma.cart_items.findFirst({
            where: {
                cart_id: cart.id,
                product_id,
            },
        })

        if (existingItem) {
            const updatedItem = await prisma.cart_items.update({
                where: { id: existingItem.id },
                data: { quantity },
            })

            return res.status(200).json({
                message: 'Cart item quantity replaced successfully',
                cartItem: updatedItem,
            })
        } else {
            const newItem = await prisma.cart_items.create({
                data: {
                    cart_id: cart.id,
                    product_id,
                    quantity,
                },
            })

            return res.status(201).json({
                message: 'Product added to cart',
                cartItem: newItem,
            })
        }
    } catch (error) {
        console.error('Error adding to cart:', error)

        if (error.status && error.message) {
            return res.status(error.status).json({ message: error.message })
        }

        return res.status(500).json({ message: 'Server error' })
    }
}

// DELETE /cart - Delete user's cart and its items
const deleteCart = async (req, res) => {
    const userId = req.user.id

    try {
        const cart = await prisma.carts.findUnique({
            where: { user_id: userId },
            select: { id: true },
        })

        if (!cart) {
            throw { status: 404, message: 'No cart found' }
        }

        await prisma.cart_items.deleteMany({
            where: { cart_id: cart.id },
        })

        await prisma.carts.delete({
            where: { id: cart.id },
        })

        return res.status(200).json({ message: 'Cart successfully deleted' })
    } catch (error) {
        console.error('Error deleting cart:', error)

        if (error.status && error.message) {
            return res.status(error.status).json({ message: error.message })
        }

        return res.status(500).json({ message: 'Server error' })
    }
}

// GET/cart - Get user's cart with items
const getCart = async (req, res) => {
    const userId = req.user.id

    try {
        const cart = await prisma.carts.findUnique({
            where: { user_id: userId },
            select: {
                items: {
                    select: {
                        id: true,
                        quantity: true,
                        product: {
                            select: {
                                id: true,
                                name: true,
                                price: true,
                                stock: true,
                                image_url: true,
                            },
                        },
                    },
                },
            },
        })

        if (!cart) {
            return res.status(200).json({
                cart: {
                    items: [],
                    total: 0,
                    itemCount: 0,
                },
            })
        }

        const total = cart.items.reduce(
            (sum, item) => sum + item.quantity * parseFloat(item.product.price),
            0
        )

        const itemCount = cart.items.reduce(
            (sum, item) => sum + item.quantity,
            0
        )

        return res.status(200).json({
            cart: {
                ...cart,
                total: parseFloat(total.toFixed(2)),
                itemCount,
            },
        })
    } catch (error) {
        console.error('Error fetching cart:', error)

        if (error.status && error.message) {
            return res.status(error.status).json({ message: error.message })
        }

        return res.status(500).json({ message: 'Server error' })
    }
}
module.exports = {
    addProduct,
    deleteCart,
    getCart,
}

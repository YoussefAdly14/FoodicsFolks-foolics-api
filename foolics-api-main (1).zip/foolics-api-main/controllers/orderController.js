const { PrismaClient } = require('../generated/prisma')
const prisma = new PrismaClient()

const createOrder = async (req, res) => {
    const userId = req.user.id

    try {
        const result = await prisma.$transaction(async (tx) => {
            const cart = await tx.carts.findUnique({
                where: { user_id: userId },
                select: { id: true },
            })

            if (!cart) {
                throw { status: 404, message: 'No cart found' }
            }

            const user = await tx.users.findUnique({
                where: { id: userId },
                select: { phone: true },
            })

            if (!user) {
                throw { status: 404, message: 'User not found' }
            }

            const cartItem = await tx.cart_items.findFirst({
                where: { cart_id: cart.id },
                select: {
                    product_id: true,
                    quantity: true,
                    product: { select: { name: true } },
                },
            })

            if (!cartItem) {
                throw { status: 404, message: 'Cart is empty' }
            }

            const product = await tx.products.findUnique({
                where: { id: cartItem.product_id },
                select: { stock: true, price: true },
            })

            if (!product) {
                throw { status: 404, message: 'Product not found' }
            }

            if (cartItem.quantity > product.stock) {
                throw { status: 400, message: 'Not enough stock available' }
            }

            const total = product.price * cartItem.quantity

            const newOrder = await tx.orders.create({
                data: {
                    user_id: userId,
                    total,
                    status: 'pending',
                },
                select: { id: true, status: true },
            })

            await tx.order_items.create({
                data: {
                    order_id: newOrder.id,
                    product_id: cartItem.product_id,
                    quantity: cartItem.quantity,
                    price_at_purchase: product.price,
                },
            })

            await tx.products.update({
                where: { id: cartItem.product_id },
                data: {
                    stock: {
                        decrement: cartItem.quantity,
                    },
                },
            })

            await tx.cart_items.deleteMany({
                where: { cart_id: cart.id },
            })

            await tx.carts.delete({
                where: { id: cart.id },
            })

            return {
                orderId: newOrder.id,
                status: newOrder.status,
                item: cartItem,
                total,
                phoneNumber: user.phone,
                productName: product.name,
            }
        })

        res.status(201).json({
            message: 'Order created successfully',
            ...result,
        })
    } catch (error) {
        if (error.status) {
            return res.status(error.status).json({ message: error.message })
        }

        console.error('Error creating order:', error)
        res.status(500).json({ message: 'Server error' })
    }
}

module.exports = { createOrder }

const getProductById = async (req, res) => {
    const { id } = req.params

    // For now, only allow id = 1
    if (id !== '1') {
        return res.status(404).json({ message: 'Product not found' })
    }

    // Mock product object
    const product = {
        id: 1,
        name: 'Foul Sandwich',
        price: 29.99,
        stock: 100,
        description: 'The best foul sandwich in the world',
        image_url: 'https://images.deliveryhero.io/image/global-menu-service/HS_SA/vendor/67689/PRODUCT/9142356/04b4b582-0f63-4998-8531-62f7605433a0.jpg?width=1440&quality=75'
    }

    res.status(200).json({
        message: 'Product retrieved successfully',
        product
    })
}

module.exports = { getProductById }

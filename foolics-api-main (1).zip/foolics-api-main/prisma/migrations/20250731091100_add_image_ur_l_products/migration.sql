/*
  Warnings:

  - You are about to drop the `SequelizeMeta` table. If the table is not empty, all the data it contains will be lost.

*/
-- AlterTable
ALTER TABLE "products" ADD COLUMN     "image_url" TEXT;

-- DropTable
DROP TABLE "SequelizeMeta";

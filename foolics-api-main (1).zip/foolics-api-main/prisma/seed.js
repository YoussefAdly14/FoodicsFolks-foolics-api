const { PrismaClient } = require('../generated/prisma')

const prisma = new PrismaClient()

async function main() {
    // Create test products if they don't exist
    const existingProducts = await prisma.products.findMany({
        where: {
            name: { in: ['Test Product 1', 'Test Product 2'] },
        },
    })

    if (existingProducts.length === 0) {
        await prisma.products.createMany({
            data: [
                {
                    name: 'Test Product 1',
                    price: 10.0,
                    stock: 100,
                    image_url: 'https://example.com/test-product-1.jpg',
                },
                {
                    name: 'Test Product 2',
                    price: 15.0,
                    stock: 50,
                    image_url: 'https://example.com/test-product-2.jpg',
                },
            ],
        })
        console.log('Created test products')
    } else {
        console.log('Test products already exist')
    }
}

main()
    .catch((e) => {
        console.error(e)
        process.exit(1)
    })
    .finally(async () => {
        await prisma.$disconnect()
    })

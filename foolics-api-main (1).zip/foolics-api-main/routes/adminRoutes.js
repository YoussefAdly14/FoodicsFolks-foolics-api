const express = require('express')
const router = express.Router()
const verifyJWT = require('../middleware/authMiddleware')

const {
    getAdminDashboard,
    loginAdmin,
    patchStock,
    updateOrderStatus,
} = require('../controllers/adminController')
const adminMiddleware = require('../middleware/adminMiddleware')

/**
 * @swagger
 * paths:
 *   /admin/dashboard:
 *     get:
 *       summary: Retrieve admin dashboard data
 *       description: Returns user details, stock information, and order details for the admin dashboard.
 *       tags:
 *         - Admin
 *       security:
 *         - bearerAuth: []
 *       responses:
 *         200:
 *           description: Admin dashboard data retrieved successfully
 *           content:
 *             application/json:
 *               schema:
 *                 type: object
 *                 properties:
 *                   message:
 *                     type: string
 *                     example: Admin dashboard data retrieved successfully
 *                   users:
 *                     type: array
 *                     items:
 *                       type: object
 *                       properties:
 *                         id:
 *                           type: integer
 *                           example: 1
 *                         full_name:
 *                           type: string
 *                           example: John Doe
 *                         phone:
 *                           type: string
 *                           example: 1234567890
 *                         email:
 *                           type: string
 *                           example: john.doe@example.com
 *                         orders:
 *                           type: array
 *                           items:
 *                             type: object
 *                             properties:
 *                               id:
 *                                 type: integer
 *                                 example: 101
 *                               total:
 *                                 type: number
 *                                 format: float
 *                                 example: 99.99
 *                               status:
 *                                 type: string
 *                                 example: completed
 *                               created_at:
 *                                 type: string
 *                                 format: date-time
 *                                 example: 2023-10-01T12:00:00Z
 *                   stock:
 *                     type: array
 *                     items:
 *                       type: object
 *                       properties:
 *                         id:
 *                           type: integer
 *                           example: 1
 *                         name:
 *                           type: string
 *                           example: Product A
 *                         stock:
 *                           type: integer
 *                           example: 50
 *         403:
 *           description: Access denied
 *           content:
 *             application/json:
 *               schema:
 *                 type: object
 *                 properties:
 *                   message:
 *                     type: string
 *                     example: Access denied
 *         500:
 *           description: Server error
 *           content:
 *             application/json:
 *               schema:
 *                 type: object
 *                 properties:
 *                   message:
 *                     type: string
 *                     example: Failed to fetch admin dashboard
 */
router.get('/dashboard', verifyJWT, adminMiddleware, getAdminDashboard)

/**
 * @swagger
 * /admin/auth/login:
 *   post:
 *     summary: Logs in an admin
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - email
 *               - password
 *             properties:
 *               email:
 *                 type: string
 *                 example: admin@example.com
 *               password:
 *                 type: string
 *                 example: adminpassword
 *     responses:
 *       200:
 *         description: Admin login successful
 *       400:
 *         description: Missing email or password
 *       401:
 *         description: Invalid credentials or not an admin
 */
router.post('/auth/login', loginAdmin)

/**
 * @swagger
 * /admin/stock:
 *   patch:
 *     summary: Updates the stock of a product
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - product_id
 *               - stock
 *             properties:
 *               product_id:
 *                 type: integer
 *                 example: 1
 *               stock:
 *                 type: integer
 *                 example: 100
 *     responses:
 *       200:
 *         description: Product stock updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Product stock updated successfully
 *                 product:
 *                   type: object
 *                   properties:
 *                     id:
 *                       type: integer
 *                       example: 1
 *                     name:
 *                       type: string
 *                       example: Product A
 *                     stock:
 *                       type: integer
 *                       example: 100
 *       400:
 *         description: Invalid input or missing fields
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Product ID and stock are required
 *       404:
 *         description: Product not found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Product not found
 *       500:
 *         description: Server error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Failed to update product stock
 */
router.patch('/stock', verifyJWT, adminMiddleware, patchStock)

/**
 * @swagger
 * /admin/orders/{id}:
 *   patch:
 *     summary: Updates the status of an order
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: The ID of the order to update
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - status
 *             properties:
 *               status:
 *                 type: string
 *                 example: processing
 *                 description: The new status of the order
 *     responses:
 *       200:
 *         description: Order status updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Order status updated successfully
 *                 order:
 *                   type: object
 *                   properties:
 *                     id:
 *                       type: integer
 *                       example: 123
 *                     status:
 *                       type: string
 *                       example: processing
 *       400:
 *         description: Invalid input or missing fields
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Order ID and status are required
 *       404:
 *         description: Order not found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Order not found
 *       500:
 *         description: Server error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Failed to update order status
 */
router.patch('/orders/:id', verifyJWT, adminMiddleware, updateOrderStatus)
module.exports = router

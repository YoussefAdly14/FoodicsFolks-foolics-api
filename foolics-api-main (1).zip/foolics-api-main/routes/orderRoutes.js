const express = require('express')
const router = express.Router()
const verifyJWT = require('../middleware/authMiddleware')
const { createOrder } = require('../controllers/orderController')

/**
 * @swagger
 * /orders:
 *   post:
 *     summary: Creates a new order from the user's cart
 *     description: Converts the user's current cart into an order, removes the cart items, and decrements product stock
 *     tags:
 *       - Orders
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       201:
 *         description: Order created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Order created successfully
 *                 orderId:
 *                   type: integer
 *                   example: 1
 *                 item:
 *                   type: object
 *                   properties:
 *                     product_id:
 *                       type: integer
 *                       example: 1
 *                     quantity:
 *                       type: integer
 *                       example: 2
 *                 total:
 *                   type: number
 *                   format: decimal
 *                   example: 99.98
 *       404:
 *         description: Cart not found or cart is empty
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: No cart found
 *       400:
 *         description: Not enough stock available
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Not enough stock available
 *       500:
 *         description: Server error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Server error
 */
router.post('/', verifyJWT, createOrder)

module.exports = router

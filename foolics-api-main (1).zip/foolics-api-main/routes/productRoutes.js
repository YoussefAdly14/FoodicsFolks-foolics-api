const express = require('express')
const router = express.Router()
const { getProductById } = require('../controllers/productController')

/**
 * @swagger
 * /products/{id}:
 *   get:
 *     summary: Get product details by ID
 *     description: Retrieves detailed information about a specific product including name, price, stock, description, and image URL
 *     tags:
 *       - Products
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Product ID (currently only supports ID 1)
 *         example: "1"
 *     responses:
 *       200:
 *         description: Product retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Product retrieved successfully
 *                 product:
 *                   type: object
 *                   properties:
 *                     id:
 *                       type: integer
 *                       example: 1
 *                     name:
 *                       type: string
 *                       example: Sample Product
 *                     price:
 *                       type: number
 *                       format: decimal
 *                       example: 29.99
 *                     stock:
 *                       type: integer
 *                       example: 100
 *                     description:
 *                       type: string
 *                       example: This is a sample product description with detailed information about the product features and benefits.
 *                     image_url:
 *                       type: string
 *                       example: https://example.com/images/sample-product.jpg
 *       404:
 *         description: Product not found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Product not found
 */
router.get('/:id', getProductById)

module.exports = router

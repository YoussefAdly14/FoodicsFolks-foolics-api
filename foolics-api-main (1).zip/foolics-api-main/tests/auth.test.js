const request = require('supertest')
const server = require('../index')
const app = require('../server')
const { PrismaClient } = require('../generated/prisma')

const prisma = new PrismaClient()

describe('Auth Endpoints', () => {
    it('POST /auth/register should register a new user', async () => {
        const newUser = {
            full_name: 'Test User',
            email: `testuser_${Date.now()}@example.com`,
            phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
            password: 'password123',
        }

        const res = await request(app).post('/auth/register').send(newUser)

        expect(res.status).toEqual(201)
        expect(res.body).toHaveProperty('user')
        expect(res.body).toHaveProperty('token')
        expect(res.body.user.email).toEqual(newUser.email)
    })

    it('POST /auth/login should log in an existing user', async () => {
        const existingUser = {
            full_name: 'Existing User',
            email: `existinguser_${Date.now()}@example.com`,
            phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
            password: 'password123',
        }
        await request(app).post('/auth/register').send(existingUser)

        const loginRes = await request(app).post('/auth/login').send({
            email: existingUser.email,
            password: existingUser.password,
        })
        expect(loginRes.status).toEqual(200)
        expect(loginRes.body).toHaveProperty('result')
        expect(loginRes.body.result).toHaveProperty('auth_token')
        expect(loginRes.body.result).toHaveProperty('user_details')
        expect(loginRes.body.result.user_details.email).toEqual(
            existingUser.email
        )
    })

    describe('Registration Failures', () => {
        it('POST /auth/register should fail with missing required fields', async () => {
            const incompleteUser = {
                full_name: 'Test User',
                email: `testuser_${Date.now()}@example.com`,
            }

            const res = await request(app)
                .post('/auth/register')
                .send(incompleteUser)

            expect(res.status).toEqual(400)
            expect(res.body).toHaveProperty(
                'message',
                'All fields are required'
            )
        })

        it('POST /auth/register should fail with duplicate email', async () => {
            const user = {
                full_name: 'Test User',
                email: `duplicate_${Date.now()}@example.com`,
                phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
                password: 'password123',
            }

            await request(app).post('/auth/register').send(user)

            const duplicateUser = {
                ...user,
                phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`, // Different phone
            }

            const res = await request(app)
                .post('/auth/register')
                .send(duplicateUser)

            expect(res.status).toEqual(400)
            expect(res.body).toHaveProperty('message', 'User already exists')
        })

        it('POST /auth/register should fail with duplicate phone', async () => {
            const phone = `01${Math.floor(
                100000000 + Math.random() * 900000000
            )}`
            const user = {
                full_name: 'Test User',
                email: `user1_${Date.now()}@example.com`,
                phone: phone,
                password: 'password123',
            }

            await request(app).post('/auth/register').send(user)

            const duplicateUser = {
                full_name: 'Another User',
                email: `user2_${Date.now()}@example.com`,
                phone: phone, // Same phone
                password: 'password123',
            }

            const res = await request(app)
                .post('/auth/register')
                .send(duplicateUser)

            expect(res.status).toEqual(400)
            expect(res.body).toHaveProperty('message', 'User already exists')
        })

        it('POST /auth/register should fail with empty string fields', async () => {
            const userWithEmptyFields = {
                full_name: '',
                email: '',
                phone: '',
                password: '',
            }

            const res = await request(app)
                .post('/auth/register')
                .send(userWithEmptyFields)

            expect(res.status).toEqual(400)
            expect(res.body).toHaveProperty(
                'message',
                'All fields are required'
            )
        })
    })

    describe('Login Failures', () => {
        it('POST /auth/login should fail with missing email', async () => {
            const loginData = {
                password: 'password123',
            }

            const res = await request(app).post('/auth/login').send(loginData)

            expect(res.status).toEqual(400)
            expect(res.body).toHaveProperty(
                'message',
                'Email and Password are required'
            )
        })

        it('POST /auth/login should fail with missing password', async () => {
            const loginData = {
                email: 'test@example.com',
            }

            const res = await request(app).post('/auth/login').send(loginData)

            expect(res.status).toEqual(400)
            expect(res.body).toHaveProperty(
                'message',
                'Email and Password are required'
            )
        })

        it('POST /auth/login should fail with non-existent email', async () => {
            const loginData = {
                email: `nonexistent_${Date.now()}@example.com`,
                password: 'password123',
            }

            const res = await request(app).post('/auth/login').send(loginData)

            expect(res.status).toEqual(401)
            expect(res.body).toHaveProperty(
                'message',
                'Invalid email or password'
            )
        })

        it('POST /auth/login should fail with wrong password', async () => {
            const user = {
                full_name: 'Test User',
                email: `wrongpass_${Date.now()}@example.com`,
                phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
                password: 'correctpassword',
            }
            await request(app).post('/auth/register').send(user)

            const loginData = {
                email: user.email,
                password: 'wrongpassword',
            }

            const res = await request(app).post('/auth/login').send(loginData)

            expect(res.status).toEqual(401)
            expect(res.body).toHaveProperty(
                'message',
                'Invalid email or password'
            )
        })

        it('POST /auth/login should fail with empty email', async () => {
            const loginData = {
                email: '',
                password: 'password123',
            }

            const res = await request(app).post('/auth/login').send(loginData)

            expect(res.status).toEqual(400)
            expect(res.body).toHaveProperty(
                'message',
                'Email and Password are required'
            )
        })

        it('POST /auth/login should fail with empty password', async () => {
            const loginData = {
                email: 'test@example.com',
                password: '',
            }

            const res = await request(app).post('/auth/login').send(loginData)

            expect(res.status).toEqual(400)
            expect(res.body).toHaveProperty(
                'message',
                'Email and Password are required'
            )
        })
    })

    afterAll(async () => {
        try {
            await prisma.users.deleteMany({
                where: {
                    OR: [
                        { email: { contains: 'testuser_' } },
                        { email: { contains: 'existinguser_' } },
                        { email: { contains: 'duplicate_' } },
                        { email: { contains: 'user1_' } },
                        { email: { contains: 'user2_' } },
                        { email: { contains: 'wrongpass_' } },
                        { email: { contains: 'nonexistent_' } },
                    ],
                },
            })
        } catch (error) {
            console.error('Error cleaning up auth test data:', error)
        } finally {
            await prisma.$disconnect()
        }
    })
})

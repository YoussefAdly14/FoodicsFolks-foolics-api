const request = require('supertest')
const server = require('../index')
const app = require('../server')
const { PrismaClient } = require('../generated/prisma')

const prisma = new PrismaClient()

describe('Cart Endpoints', () => {
    let authToken
    let testUser

    beforeAll(async () => {
        const userData = {
            full_name: 'Test Cart User',
            email: `cartuser_${Date.now()}@example.com`,
            phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
            password: 'password123',
        }

        const registerRes = await request(app)
            .post('/auth/register')
            .send(userData)

        authToken = registerRes.body.token
        testUser = registerRes.body.user
    })

    describe('POST /cart', () => {
        it('should add a product to cart successfully', async () => {
            // Get the first available product
            const product = await prisma.products.findFirst()
            if (!product) {
                throw new Error('No products available for testing')
            }

            const cartData = {
                product_id: product.id,
                quantity: 2,
            }

            const res = await request(app)
                .post('/cart')
                .set('Authorization', `Bearer ${authToken}`)
                .send(cartData)

            expect(res.status).toEqual(201)
            expect(res.body).toHaveProperty('message', 'Product added to cart')
            expect(res.body).toHaveProperty('cartItem')
            expect(res.body.cartItem).toHaveProperty(
                'product_id',
                cartData.product_id
            )
            expect(res.body.cartItem).toHaveProperty(
                'quantity',
                cartData.quantity
            )
        })

        it('should update cart item quantity when product already exists', async () => {
            // Get the first available product
            const product = await prisma.products.findFirst()
            if (!product) {
                throw new Error('No products available for testing')
            }

            const cartData = {
                product_id: product.id,
                quantity: 5,
            }

            const res = await request(app)
                .post('/cart')
                .set('Authorization', `Bearer ${authToken}`)
                .send(cartData)

            expect(res.status).toEqual(200)
            expect(res.body).toHaveProperty(
                'message',
                'Cart item quantity replaced successfully'
            )
            expect(res.body).toHaveProperty('cartItem')
            expect(res.body.cartItem).toHaveProperty(
                'quantity',
                cartData.quantity
            )
        })

        it('should fail without authentication token', async () => {
            // Get the first available product
            const product = await prisma.products.findFirst()
            if (!product) {
                throw new Error('No products available for testing')
            }

            const cartData = {
                product_id: product.id,
                quantity: 2,
            }

            const res = await request(app).post('/cart').send(cartData)

            expect(res.status).toEqual(401)
            expect(res.body).toHaveProperty(
                'message',
                'Unauthorized: No token provided'
            )
        })

        it('should fail with invalid authentication token', async () => {
            // Get the first available product
            const product = await prisma.products.findFirst()
            if (!product) {
                throw new Error('No products available for testing')
            }

            const cartData = {
                product_id: product.id,
                quantity: 2,
            }

            const res = await request(app)
                .post('/cart')
                .set('Authorization', 'Bearer invalid_token')
                .send(cartData)

            expect(res.status).toEqual(403)
            expect(res.body).toHaveProperty(
                'message',
                'Forbidden: Invalid or expired token'
            )
        })

        it('should fail with missing product_id', async () => {
            const cartData = {
                quantity: 2,
            }

            const res = await request(app)
                .post('/cart')
                .set('Authorization', `Bearer ${authToken}`)
                .send(cartData)

            expect(res.status).toEqual(400)
            expect(res.body).toHaveProperty(
                'message',
                'Quantity and product_id are required'
            )
        })

        it('should fail with missing quantity', async () => {
            // Get the first available product
            const product = await prisma.products.findFirst()
            if (!product) {
                throw new Error('No products available for testing')
            }

            const cartData = {
                product_id: product.id,
            }

            const res = await request(app)
                .post('/cart')
                .set('Authorization', `Bearer ${authToken}`)
                .send(cartData)

            expect(res.status).toEqual(400)
            expect(res.body).toHaveProperty(
                'message',
                'Quantity and product_id are required'
            )
        })

        it('should fail with zero or negative quantity', async () => {
            // Get the first available product
            const product = await prisma.products.findFirst()
            if (!product) {
                throw new Error('No products available for testing')
            }

            const cartData = {
                product_id: product.id,
                quantity: 0,
            }

            const res = await request(app)
                .post('/cart')
                .set('Authorization', `Bearer ${authToken}`)
                .send(cartData)

            expect(res.status).toEqual(400)
            expect(res.body).toHaveProperty(
                'message',
                'Quantity must be a positive value'
            )
        })

        it('should fail with non-existent product', async () => {
            const cartData = {
                product_id: 99999,
                quantity: 1,
            }

            const res = await request(app)
                .post('/cart')
                .set('Authorization', `Bearer ${authToken}`)
                .send(cartData)

            expect(res.status).toEqual(404)
            expect(res.body).toHaveProperty('message', 'Product not found')
        })
    })

    describe('GET /cart', () => {
        beforeEach(async () => {
            // Add a product to cart for testing
            const product = await prisma.products.findFirst()
            if (!product) {
                throw new Error('No products available for testing')
            }

            await request(app)
                .post('/cart')
                .set('Authorization', `Bearer ${authToken}`)
                .send({
                    product_id: product.id,
                    quantity: 3,
                })
        })

        it('should retrieve user cart successfully', async () => {
            const res = await request(app)
                .get('/cart')
                .set('Authorization', `Bearer ${authToken}`)

            expect(res.status).toEqual(200)
            expect(res.body.cart).toHaveProperty('items')
            res.body.cart.items.forEach((item) => {
                expect(item.product).toHaveProperty('image_url')
                expect(typeof item.product.image_url).toBe('string')
            })
        })

        it('should fail without authentication token', async () => {
            const res = await request(app).get('/cart')

            expect(res.status).toEqual(401)
            expect(res.body).toHaveProperty(
                'message',
                'Unauthorized: No token provided'
            )
        })

        it('should fail with invalid authentication token', async () => {
            const res = await request(app)
                .get('/cart')
                .set('Authorization', 'Bearer invalid_token')

            expect(res.status).toEqual(403)
            expect(res.body).toHaveProperty(
                'message',
                'Forbidden: Invalid or expired token'
            )
        })

        it('should return empty cart for user with no cart', async () => {
            // Create a new user without any cart items
            const newUserData = {
                full_name: 'Empty Cart User',
                email: `emptycart_${Date.now()}@example.com`,
                phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
                password: 'password123',
            }

            const registerRes = await request(app)
                .post('/auth/register')
                .send(newUserData)

            const newUserToken = registerRes.body.token

            const res = await request(app)
                .get('/cart')
                .set('Authorization', `Bearer ${newUserToken}`)

            expect(res.status).toEqual(200)
            expect(res.body).toHaveProperty('cart')
            expect(res.body.cart).toHaveProperty('items', [])
            expect(res.body.cart).toHaveProperty('total', 0)
            expect(res.body.cart).toHaveProperty('itemCount', 0)
        })
    })

    describe('DELETE /cart', () => {
        beforeEach(async () => {
            await request(app)
                .post('/cart')
                .set('Authorization', `Bearer ${authToken}`)
                .send({
                    product_id: 1,
                    quantity: 2,
                })
        })

        it('should delete user cart successfully', async () => {
            const res = await request(app)
                .delete('/cart')
                .set('Authorization', `Bearer ${authToken}`)

            expect(res.status).toEqual(200)
            expect(res.body).toHaveProperty(
                'message',
                'Cart successfully deleted'
            )
        })

        it('should fail without authentication token', async () => {
            const res = await request(app).delete('/cart')

            expect(res.status).toEqual(401)
            expect(res.body).toHaveProperty(
                'message',
                'Unauthorized: No token provided'
            )
        })

        it('should fail with invalid authentication token', async () => {
            const res = await request(app)
                .delete('/cart')
                .set('Authorization', 'Bearer invalid_token')

            expect(res.status).toEqual(403)
            expect(res.body).toHaveProperty(
                'message',
                'Forbidden: Invalid or expired token'
            )
        })

        it('should fail when trying to delete non-existent cart', async () => {
            const newUserData = {
                full_name: 'No Cart User',
                email: `nocart_${Date.now()}@example.com`,
                phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
                password: 'password123',
            }

            const registerRes = await request(app)
                .post('/auth/register')
                .send(newUserData)

            const newUserToken = registerRes.body.token

            const res = await request(app)
                .delete('/cart')
                .set('Authorization', `Bearer ${newUserToken}`)

            expect(res.status).toEqual(404)
            expect(res.body).toHaveProperty('message', 'No cart found')
        })

        it('should verify cart is actually deleted after deletion', async () => {
            const deleteRes = await request(app)
                .delete('/cart')
                .set('Authorization', `Bearer ${authToken}`)

            expect(deleteRes.status).toEqual(200)

            const getRes = await request(app)
                .get('/cart')
                .set('Authorization', `Bearer ${authToken}`)

            expect(getRes.status).toEqual(200)
            expect(getRes.body.cart.items).toEqual([])
            expect(getRes.body.cart.total).toEqual(0)
            expect(getRes.body.cart.itemCount).toEqual(0)
        })
    })

    afterAll(async () => {
        try {
            await prisma.cart_items.deleteMany({
                where: {
                    cart: {
                        user: {
                            OR: [
                                { email: { contains: 'cartuser_' } },
                                { email: { contains: 'emptycart_' } },
                                { email: { contains: 'nocart_' } },
                            ],
                        },
                    },
                },
            })

            await prisma.carts.deleteMany({
                where: {
                    user: {
                        OR: [
                            { email: { contains: 'cartuser_' } },
                            { email: { contains: 'emptycart_' } },
                            { email: { contains: 'nocart_' } },
                        ],
                    },
                },
            })

            await prisma.users.deleteMany({
                where: {
                    OR: [
                        { email: { contains: 'cartuser_' } },
                        { email: { contains: 'emptycart_' } },
                        { email: { contains: 'nocart_' } },
                    ],
                },
            })
        } catch (error) {
            console.error('Error cleaning up cart test data:', error)
        } finally {
            await prisma.$disconnect()
        }
    })
})

const request = require('supertest')
const app = require('../server')
const { PrismaClient } = require('../generated/prisma')

const prisma = new PrismaClient()

describe('GET /admin/dashboard', () => {
    let adminToken

    beforeAll(async () => {
        // Create an admin user
        const adminUser = await prisma.users.create({
            data: {
                full_name: 'Admin User',
                email: `admin_${Date.now()}@example.com`,
                phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
                password_hash: await require('bcrypt').hash('password123', 10),
                is_admin: true,
            },
        })

        // Login as admin to get the token
        const loginRes = await request(app).post('/admin/auth/login').send({
            email: adminUser.email,
            password: 'password123',
        })

        adminToken = loginRes.body.result.auth_token

        // Create customers with orders
        const customer1 = await prisma.users.create({
            data: {
                full_name: 'Customer One',
                email: `customer1_${Date.now()}@example.com`,
                phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
                password_hash: await require('bcrypt').hash('password123', 10),
                is_admin: false,
            },
        })

        const customer2 = await prisma.users.create({
            data: {
                full_name: 'Customer Two',
                email: `customer2_${Date.now()}@example.com`,
                phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
                password_hash: await require('bcrypt').hash('password123', 10),
                is_admin: false,
            },
        })

        await prisma.orders.create({
            data: {
                user_id: customer1.id,
                total: 100.0,
                status: 'completed',
                created_at: new Date(),
            },
        })

        await prisma.orders.create({
            data: {
                user_id: customer2.id,
                total: 200.0,
                status: 'pending',
                created_at: new Date(),
            },
        })

        // Create stock data
        await prisma.products.createMany({
            data: [
                { name: 'Product A', stock: 50, price: 10.0 },
                { name: 'Product B', stock: 30, price: 15.0 },
            ],
        })
    })

    it('should retrieve admin dashboard data successfully', async () => {
        const res = await request(app)
            .get('/admin/dashboard')
            .set('Authorization', `Bearer ${adminToken}`)

        expect(res.status).toEqual(200)
        expect(res.body).toHaveProperty(
            'message',
            'Admin dashboard data retrieved successfully'
        )
        expect(res.body).toHaveProperty('orders')
        expect(res.body).toHaveProperty('stock')

        // Validate orders with user details and order items
        expect(Array.isArray(res.body.orders)).toBe(true)
        expect(res.body.orders.length).toBeGreaterThanOrEqual(1)
        res.body.orders.forEach((order) => {
            expect(order).toHaveProperty('id')
            expect(order).toHaveProperty('total')
            expect(order).toHaveProperty('status')
            expect(order).toHaveProperty('created_at')
            expect(order).toHaveProperty('user')
            expect(order.user).toHaveProperty('id')
            expect(order.user).toHaveProperty('full_name')
            expect(order.user).toHaveProperty('email')
            expect(order.user).toHaveProperty('phone')

            // Validate order items
            expect(order).toHaveProperty('order_items')
            expect(Array.isArray(order.order_items)).toBe(true)
            order.order_items.forEach((item) => {
                expect(item).toHaveProperty('product')
                expect(item.product).toHaveProperty('id')
                expect(item.product).toHaveProperty('name')
                expect(item).toHaveProperty('quantity')
            })
        })

        // Validate stock data
        expect(Array.isArray(res.body.stock)).toBe(true)
        expect(res.body.stock.length).toBeGreaterThanOrEqual(2)
        res.body.stock.forEach((product) => {
            expect(product).toHaveProperty('id')
            expect(product).toHaveProperty('name')
            expect(product).toHaveProperty('stock')
        })
    })

    afterAll(async () => {
        // Cleanup test data
        await prisma.cart_items.deleteMany({}) // Delete cart items first
        await prisma.orders.deleteMany({})
        await prisma.users.deleteMany({
            where: {
                email: { contains: 'customer' },
            },
        })
        await prisma.users.deleteMany({
            where: {
                email: { contains: 'admin_' },
            },
        })
        await prisma.$disconnect()
    })
})

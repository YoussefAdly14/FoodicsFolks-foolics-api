const request = require('supertest')
const server = require('../index')
const app = require('../server')
const { PrismaClient } = require('../generated/prisma')

const prisma = new PrismaClient()

describe('Order Endpoints', () => {
    let authToken
    let testUser

    beforeAll(async () => {
        const userData = {
            full_name: 'Test User',
            email: `testuser_${Date.now()}@example.com`,
            phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
            password: 'password123',
        }

        const registerRes = await request(app)
            .post('/auth/register')
            .send(userData)

        authToken = registerRes.body.token
        testUser = registerRes.body.user
    })

    describe('POST /orders', () => {
        it('should create an order successfully from cart', async () => {
            // Get the first available product
            const product = await prisma.products.findFirst()
            if (!product) {
                throw new Error('No products available for testing')
            }

            const cartRes = await request(app)
                .post('/cart')
                .set('Authorization', `Bearer ${authToken}`)
                .send({
                    product_id: product.id,
                    quantity: 2,
                })

            expect(cartRes.status).toEqual(201)
            expect(cartRes.body).toHaveProperty(
                'message',
                'Product added to cart'
            )

            const res = await request(app)
                .post('/orders')
                .set('Authorization', `Bearer ${authToken}`)

            expect(res.status).toEqual(201)
            expect(res.body).toHaveProperty(
                'message',
                'Order created successfully'
            )
            expect(res.body).toHaveProperty('orderId')
            expect(res.body).toHaveProperty('item')
            expect(res.body).toHaveProperty('total')
            expect(res.body.item).toHaveProperty('product_id')
            expect(res.body.item).toHaveProperty('quantity')
            expect(res.body.item.quantity).toEqual(2)
            expect(typeof res.body.total).toBe('number')
        })

        it('should fail when user has no cart', async () => {
            const newUserData = {
                full_name: 'New User',
                email: `newuser_${Date.now()}@example.com`,
                phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
                password: 'password123',
            }

            const registerRes = await request(app)
                .post('/auth/register')
                .send(newUserData)

            expect(registerRes.status).toEqual(201)
            const newUserToken = registerRes.body.token

            const res = await request(app)
                .post('/orders')
                .set('Authorization', `Bearer ${newUserToken}`)

            expect(res.status).toEqual(404)
            expect(res.body).toHaveProperty('message', 'No cart found')
        })

        it('should fail without authentication token', async () => {
            const res = await request(app).post('/orders')

            expect(res.status).toEqual(401)
            expect(res.body).toHaveProperty(
                'message',
                'Unauthorized: No token provided'
            )
        })

        it('should fail with invalid authentication token', async () => {
            const res = await request(app)
                .post('/orders')
                .set('Authorization', 'Bearer invalid_token')

            expect(res.status).toEqual(403)
            expect(res.body).toHaveProperty(
                'message',
                'Forbidden: Invalid or expired token'
            )
        })

        it('should fail with malformed authorization header', async () => {
            const res = await request(app)
                .post('/orders')
                .set('Authorization', 'invalid_format')

            expect(res.status).toEqual(401)
            expect(res.body).toHaveProperty(
                'message',
                'Unauthorized: No token provided'
            )
        })

        it('should fail when adding non-existent product to cart', async () => {
            const userData = {
                full_name: 'Another User',
                email: `anotheruser_${Date.now()}@example.com`,
                phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
                password: 'password123',
            }

            const registerRes = await request(app)
                .post('/auth/register')
                .send(userData)

            expect(registerRes.status).toEqual(201)
            const userToken = registerRes.body.token

            const cartRes = await request(app)
                .post('/cart')
                .set('Authorization', `Bearer ${userToken}`)
                .send({
                    product_id: 99999, // Non-existent product ID
                    quantity: 1,
                })

            expect(cartRes.status).toEqual(404)

            const res = await request(app)
                .post('/orders')
                .set('Authorization', `Bearer ${userToken}`)

            expect(res.status).toEqual(404)
            expect(res.body).toHaveProperty('message', 'No cart found')
        })

        it('should handle order creation with valid cart item', async () => {
            const userData = {
                full_name: 'Fresh User',
                email: `freshuser_${Date.now()}@example.com`,
                phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
                password: 'password123',
            }

            const registerRes = await request(app)
                .post('/auth/register')
                .send(userData)

            expect(registerRes.status).toEqual(201)
            const userToken = registerRes.body.token

            const cartRes = await request(app)
                .post('/cart')
                .set('Authorization', `Bearer ${userToken}`)
                .send({
                    product_id: 1,
                    quantity: 1,
                })

            expect(cartRes.status).toEqual(201)

            const res = await request(app)
                .post('/orders')
                .set('Authorization', `Bearer ${userToken}`)

            expect(res.status).toEqual(201)
            expect(res.body).toHaveProperty(
                'message',
                'Order created successfully'
            )
            expect(res.body).toHaveProperty('orderId')
            expect(typeof res.body.orderId).toBe('number')
        })

        it('should return correct response structure on successful order', async () => {
            const userData = {
                full_name: 'Structure Test User',
                email: `structureuser_${Date.now()}@example.com`,
                phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
                password: 'password123',
            }

            const registerRes = await request(app)
                .post('/auth/register')
                .send(userData)

            expect(registerRes.status).toEqual(201)
            const userToken = registerRes.body.token

            const cartRes = await request(app)
                .post('/cart')
                .set('Authorization', `Bearer ${userToken}`)
                .send({
                    product_id: 1,
                    quantity: 3,
                })

            expect(cartRes.status).toEqual(201)

            const res = await request(app)
                .post('/orders')
                .set('Authorization', `Bearer ${userToken}`)

            expect(res.status).toEqual(201)
            expect(res.body).toHaveProperty('message')
            expect(res.body).toHaveProperty('orderId')
            expect(res.body).toHaveProperty('item')
            expect(res.body).toHaveProperty('total')
            expect(res.body.item).toHaveProperty('product_id')
            expect(res.body.item).toHaveProperty('quantity')
            expect(res.body.item.quantity).toEqual(3)
        })

        it('should calculate total correctly', async () => {
            const userData = {
                full_name: 'Total Test User',
                email: `totaluser_${Date.now()}@example.com`,
                phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
                password: 'password123',
            }

            const registerRes = await request(app)
                .post('/auth/register')
                .send(userData)

            expect(registerRes.status).toEqual(201)
            const userToken = registerRes.body.token

            const cartRes = await request(app)
                .post('/cart')
                .set('Authorization', `Bearer ${userToken}`)
                .send({
                    product_id: 1,
                    quantity: 4,
                })

            expect(cartRes.status).toEqual(201)

            const res = await request(app)
                .post('/orders')
                .set('Authorization', `Bearer ${userToken}`)

            expect(res.status).toEqual(201)
            expect(res.body).toHaveProperty('total')
            expect(typeof res.body.total).toBe('number')
            expect(parseFloat(res.body.total)).toBeGreaterThan(0)
        })

        it('should return phone number in order response', async () => {
            const userData = {
                full_name: 'Phone Test User',
                email: `phoneuser_${Date.now()}@example.com`,
                phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
                password: 'password123',
            }

            const registerRes = await request(app)
                .post('/auth/register')
                .send(userData)

            expect(registerRes.status).toEqual(201)
            const userToken = registerRes.body.token

            const cartRes = await request(app)
                .post('/cart')
                .set('Authorization', `Bearer ${userToken}`)
                .send({
                    product_id: 1,
                    quantity: 1,
                })

            expect(cartRes.status).toEqual(201)

            const res = await request(app)
                .post('/orders')
                .set('Authorization', `Bearer ${userToken}`)

            expect(res.status).toEqual(201)
            expect(res.body).toHaveProperty('phoneNumber')
            expect(res.body.phoneNumber).toEqual(userData.phone)
            expect(typeof res.body.phoneNumber).toBe('string')
        })
    })

    afterAll(async () => {
        try {
            // Delete order items first (foreign key dependency)
            await prisma.order_items.deleteMany({
                where: {
                    order: {
                        user: {
                            email: {
                                contains: 'user_',
                            },
                        },
                    },
                },
            })

            // Delete orders
            await prisma.orders.deleteMany({
                where: {
                    user: {
                        email: {
                            contains: 'user_',
                        },
                    },
                },
            })

            // Delete cart items
            await prisma.cart_items.deleteMany({
                where: {
                    cart: {
                        user: {
                            email: {
                                contains: 'user_',
                            },
                        },
                    },
                },
            })

            // Delete carts
            await prisma.carts.deleteMany({
                where: {
                    user: {
                        email: {
                            contains: 'user_',
                        },
                    },
                },
            })

            // Delete test users (all emails contain 'user_' pattern)
            await prisma.users.deleteMany({
                where: {
                    email: {
                        contains: 'user_',
                    },
                },
            })

            await prisma.$disconnect()
        } catch (error) {
            console.error('Error cleaning up test data:', error)
            await prisma.$disconnect()
        }
    })
})

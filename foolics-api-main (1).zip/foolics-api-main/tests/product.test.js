const request = require('supertest')
const app = require('../server')

describe('Product Endpoints', () => {
    describe('GET /products/:id', () => {
        it('should return product details for valid ID', async () => {
            const productId = '1'

            const res = await request(app)
                .get(`/products/${productId}`)
                .expect(200)

            expect(res.body).toHaveProperty('message', 'Product retrieved successfully')
            expect(res.body).toHaveProperty('product')

            const product = res.body.product
            expect(product).toHaveProperty('id', 1)
            expect(product).toHaveProperty('name', 'Foul Sandwich')
            expect(product).toHaveProperty('price', 29.99)
            expect(product).toHaveProperty('stock', 100)
            expect(product).toHaveProperty('description')
            expect(product).toHaveProperty('image_url')
            expect(typeof product.description).toBe('string')
            expect(typeof product.image_url).toBe('string')
        })

        it('should return 404 for unsupported product ID', async () => {
            const productId = '2'

            const res = await request(app)
                .get(`/products/${productId}`)
                .expect(404)

            expect(res.body).toHaveProperty('message', 'Product not found')
        })

        it('should return 404 for invalid product ID format', async () => {
            const productId = 'invalid'

            const res = await request(app)
                .get(`/products/${productId}`)
                .expect(404)

            expect(res.body).toHaveProperty('message', 'Product not found')
        })
    })
})

const request = require('supertest')
const app = require('../server')
const { PrismaClient } = require('../generated/prisma')

const prisma = new PrismaClient()

describe('PATCH /admin/orders/:id', () => {
    let adminToken
    let order

    beforeAll(async () => {
        // Clean up any existing test users
        await prisma.users.deleteMany({
            where: {
                email: { contains: 'admin_test' }
            }
        })

        const adminUser = await prisma.users.create({
            data: {
                full_name: 'Admin User',
                email: `admin_test_${Date.now()}@example.com`,
                phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
                password_hash: await require('bcrypt').hash('password123', 10),
                is_admin: true,
            },
        })

        const loginRes = await request(app).post('/admin/auth/login').send({
            email: adminUser.email,
            password: 'password123',
        })

        adminToken = loginRes.body.result.auth_token

        const user = await prisma.users.create({
            data: {
                full_name: 'Test User',
                email: `testuser_${Date.now()}@example.com`,
                phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
                password_hash: await require('bcrypt').hash('password123', 10),
                is_admin: false,
            },
        })

        order = await prisma.orders.create({
            data: {
                user_id: user.id,
                total: 100.0,
                status: 'pending',
                created_at: new Date(),
            },
        })
    })

    it('should update order status successfully', async () => {
        const res = await request(app)
            .patch(`/admin/orders/${order.id}`)
            .set('Authorization', `Bearer ${adminToken}`)
            .send({ status: 'shipped' })

        expect(res.status).toEqual(200)
        expect(res.body).toHaveProperty(
            'message',
            'Order status updated successfully'
        )
        expect(res.body).toHaveProperty('order')
        expect(res.body.order).toHaveProperty('id', order.id)
        expect(res.body.order).toHaveProperty('status', 'shipped')
    })

    it('should fail with invalid status', async () => {
        const res = await request(app)
            .patch(`/admin/orders/${order.id}`)
            .set('Authorization', `Bearer ${adminToken}`)
            .send({ status: 'invalid_status' })

        expect(res.status).toEqual(400)
        expect(res.body).toHaveProperty('message', 'Invalid order status')
    })

    it('should fail with missing status', async () => {
        const res = await request(app)
            .patch(`/admin/orders/${order.id}`)
            .set('Authorization', `Bearer ${adminToken}`)
            .send({})

        expect(res.status).toEqual(400)
        expect(res.body).toHaveProperty(
            'message',
            'Order ID and status are required'
        )
    })

    it('should fail with non-existent order ID', async () => {
        const res = await request(app)
            .patch('/admin/orders/99999')
            .set('Authorization', `Bearer ${adminToken}`)
            .send({ status: 'processing' })

        expect(res.status).toEqual(404)
        expect(res.body).toHaveProperty('message', 'Order not found')
    })

    it('should fail without authentication token', async () => {
        const res = await request(app)
            .patch(`/admin/orders/${order.id}`)
            .send({ status: 'delivered' })

        expect(res.status).toEqual(401)
        expect(res.body).toHaveProperty(
            'message',
            'Unauthorized: No token provided'
        )
    })

    it('should fail with invalid authentication token', async () => {
        const res = await request(app)
            .patch(`/admin/orders/${order.id}`)
            .set('Authorization', 'Bearer invalid_token')
            .send({ status: 'pending' })

        expect(res.status).toEqual(403)
        expect(res.body).toHaveProperty(
            'message',
            'Forbidden: Invalid or expired token'
        )
    })

    afterAll(async () => {
        await prisma.orders.deleteMany({})
        await prisma.users.deleteMany({
            where: {
                email: { contains: 'admin_' },
            },
        })
        await prisma.users.deleteMany({
            where: {
                email: { contains: 'testuser_' },
            },
        })
    })
})

const request = require('supertest')
const app = require('../server')
const { PrismaClient } = require('../generated/prisma')

const prisma = new PrismaClient()

describe('PATCH /admin/stock', () => {
    let adminToken

    beforeAll(async () => {
        // Clean up any existing test users and products
        await prisma.users.deleteMany({
            where: {
                email: { contains: 'admin_stock_test' }
            }
        })

        await prisma.products.deleteMany({
            where: {
                name: { in: ['Product A', 'Product B'] }
            }
        })

        const adminUser = await prisma.users.create({
            data: {
                full_name: 'Admin User',
                email: `admin_stock_test_${Date.now()}@example.com`,
                phone: `01${Math.floor(100000000 + Math.random() * 900000000)}`,
                password_hash: await require('bcrypt').hash('password123', 10),
                is_admin: true,
            },
        })

        const loginRes = await request(app).post('/admin/auth/login').send({
            email: adminUser.email,
            password: 'password123',
        })

        adminToken = loginRes.body.result.auth_token

        await prisma.products.createMany({
            data: [
                { name: 'Product A', stock: 50, price: 10.0 },
                { name: 'Product B', stock: 30, price: 15.0 },
            ],
        })
    })

    it('should update product stock successfully', async () => {
        const product = await prisma.products.findFirst({
            where: { name: 'Product A' },
        })

        const res = await request(app)
            .patch('/admin/stock')
            .set('Authorization', `Bearer ${adminToken}`)
            .send({
                product_id: product.id,
                stock: 100,
            })

        expect(res.status).toEqual(200)
        expect(res.body).toHaveProperty(
            'message',
            'Product stock updated successfully'
        )
        expect(res.body).toHaveProperty('product')
        expect(res.body.product).toHaveProperty('id', product.id)
        expect(res.body.product).toHaveProperty('stock', 100)
    })

    it('should fail with missing product_id', async () => {
        const res = await request(app)
            .patch('/admin/stock')
            .set('Authorization', `Bearer ${adminToken}`)
            .send({
                stock: 100,
            })

        expect(res.status).toEqual(400)
        expect(res.body).toHaveProperty(
            'message',
            'Product ID and stock are required'
        )
    })

    it('should fail with missing stock', async () => {
        const product = await prisma.products.findFirst({
            where: { name: 'Product A' },
        })

        const res = await request(app)
            .patch('/admin/stock')
            .set('Authorization', `Bearer ${adminToken}`)
            .send({
                product_id: product.id,
            })

        expect(res.status).toEqual(400)
        expect(res.body).toHaveProperty(
            'message',
            'Product ID and stock are required'
        )
    })

    it('should fail with negative stock value', async () => {
        const product = await prisma.products.findFirst({
            where: { name: 'Product A' },
        })

        const res = await request(app)
            .patch('/admin/stock')
            .set('Authorization', `Bearer ${adminToken}`)
            .send({
                product_id: product.id,
                stock: -10,
            })

        expect(res.status).toEqual(400)
        expect(res.body).toHaveProperty(
            'message',
            'Stock must be a positive integer'
        )
    })

    it('should fail with non-integer stock value', async () => {
        const product = await prisma.products.findFirst({
            where: { name: 'Product A' },
        })

        const res = await request(app)
            .patch('/admin/stock')
            .set('Authorization', `Bearer ${adminToken}`)
            .send({
                product_id: product.id,
                stock: 10.5,
            })

        expect(res.status).toEqual(400)
        expect(res.body).toHaveProperty(
            'message',
            'Stock must be a positive integer'
        )
    })

    it('should fail with non-existent product_id', async () => {
        const res = await request(app)
            .patch('/admin/stock')
            .set('Authorization', `Bearer ${adminToken}`)
            .send({
                product_id: 99999,
                stock: 100,
            })

        expect(res.status).toEqual(404)
        expect(res.body).toHaveProperty('message', 'Product not found')
    })

    it('should fail without authentication token', async () => {
        const product = await prisma.products.findFirst({
            where: { name: 'Product A' },
        })

        const res = await request(app).patch('/admin/stock').send({
            product_id: product.id,
            stock: 100,
        })

        expect(res.status).toEqual(401)
        expect(res.body).toHaveProperty(
            'message',
            'Unauthorized: No token provided'
        )
    })

    it('should fail with invalid authentication token', async () => {
        const product = await prisma.products.findFirst({
            where: { name: 'Product A' },
        })

        const res = await request(app)
            .patch('/admin/stock')
            .set('Authorization', 'Bearer invalid_token')
            .send({
                product_id: product.id,
                stock: 100,
            })

        expect(res.status).toEqual(403)
        expect(res.body).toHaveProperty(
            'message',
            'Forbidden: Invalid or expired token'
        )
    })

    afterAll(async () => {
        await prisma.users.deleteMany({
            where: {
                email: { contains: 'admin_' },
            },
        })
        await prisma.$disconnect()
    })
})
